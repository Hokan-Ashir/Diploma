function myFunction()
{
document.getElementById("demo").innerHTML="My First JavaScript Function";
}
'eval()'
eval()'eval()