#!/usr/bin/env/ python
# -*- coding: utf-8 -*-
import re
from pyhtmlanalyzer.commonFunctions.commonConnectionUtils import commonConnectionUtils
from pyhtmlanalyzer.commonFunctions.plottingFunctions import plottingFunctions
from pyhtmlanalyzer.full.html.htmlAnalyzer import htmlAnalyzer
from pyhtmlanalyzer.pyHTMLAnalyzer import pyHTMLAnalyzer

if __name__ == "__main__":
    analyzer = pyHTMLAnalyzer("config")
    #result = commonConnectionUtils.openFile("xmlFiles/ca_keys.xml")[0]
    #analyzer.printAnalyzedPageFeatures("xmlFiles/ca_keys.xml")
    #result = commonConnectionUtils.openFile("xmlFiles/копия test.xml")[0]
    #analyzer.printAnalyzedHTMLFileFeatures("xmlFiles/2575.html")
    #analyzer.printAnalyzedPageFeatures("http://blajdsadw")
    analyzer.printAnalyzedPageFeatures("http://www.tutorialspoint.com/python/string_split.htm")
    #analyzer.printAnalyzedHTMLFileFeatures("xmlFiles/VLC.htm")
    #analyzer.printAnalyzedHTMLFileFeatures("xmlFiles/4042.html")
    html = htmlAnalyzer.printPagesPercentageMismatch(commonConnectionUtils.openFile('xmlFiles/VLC.htm')[0],
                                                     commonConnectionUtils.openFile('xmlFiles/VLC1.htm')[0])
    #plottingFunctions.plotArrayOfValues('test', [10, 20, 40], [100, 400, 300], 'xLabel', 'yLabel')

    # TODO Global
    # - sql-integration (DB-4-lab, postgres preferable)
    # - browser-plugin - must save malicious url for post-analysis, black/white-listing
    # - statistics-class so as example and graphics
    # - cashing
    # - multi-threading
    # - optimizations
    # kinda class-variables for listOfAllStrings, listOfScriptFiles, listOfScriptNodes etc.
    # http://www.ibm.com/developerworks/ru/library/x-hiperfparse/

    # TODO ask
    # in <script> tags with @src attribute no embed script will be executed, is there a way to break this rule?