import re
import timeit
from pyhtmlanalyzer.commonFunctions.commonConnectionUtils import commonConnectionUtils
from pyhtmlanalyzer.full.html.htmlAnalyzer import htmlAnalyzer
from pyhtmlanalyzer.full.script.scriptAnalyzer import scriptAnalyzer
from pyhtmlanalyzer.full.url.urlAnalyzer import urlAnalyzer

__author__ = 'hokan'

class pyHTMLAnalyzer:
    htmlAnalyzerModule = None
    scriptAnalyzerModule = None
    urlAnalyzerModule = None

    def __init__(self, configFileName):
        configList = self.getConfigList(configFileName)
        self.htmlAnalyzerModule = htmlAnalyzer(configList[0])
        self.scriptAnalyzerModule = scriptAnalyzer(configList[1])
        self.urlAnalyzerModule = urlAnalyzer(configList[2])

    # get config list for various analyzer modules
    def getConfigList(self, configFileName):
        configFile = open(configFileName, 'r')
        listOfHTMLFeatures = ["html.elements.with.small.area",
                              "html.non.dulpicated.elemets",
                              "html.void.elements",
                              "html.included.urls.elements",
                              "html.under.head.elements",
                              "html.out.of.root.elements",
                              "html.block.level.elements",
                              "html.non.block.elements",
                              "html.no.block.content.inline.elements",
                              "html.all.tag.names"]
        listOfScriptFeatures = ["script.set.timeout.functions",
                                "script.keywords",
                                "script.built.in.functions",
                                "script.suspicious.tags",
                                "script.events",
                                "script.event.functions",
                                "script.string.modification.functions",
                                "script.deobfuscation.functions",
                                "script.DOM.modifying.methods",
                                "script.fingerprinting.functions"]
        listOfURLFeatures = ["url.suspicious.file.names",
                             "url.suspicious.patterns"]
        htmlConfigDict = {}
        scriptConfigDict = {}
        urlConfigDict = {}
        regExp = re.compile(r'[^\n\s=,]+')
        for line in configFile:
            # comments
            if line.startswith("#"):
                continue
            parseResult = re.findall(regExp, line)
            if parseResult == []:
                continue

            # html features
            if parseResult[0] in listOfHTMLFeatures:
                htmlConfigDict[parseResult[0]] = parseResult
                htmlConfigDict[parseResult[0]].pop(0)

            # script features
            if parseResult[0] in listOfScriptFeatures:
                scriptConfigDict[parseResult[0]] = parseResult
                scriptConfigDict[parseResult[0]].pop(0)

            # url features
            if parseResult[0] in listOfURLFeatures:
                urlConfigDict[parseResult[0]] = parseResult
                urlConfigDict[parseResult[0]].pop(0)

        return [htmlConfigDict, scriptConfigDict, urlConfigDict]

    # print-function group
    def printAnalyzedAbstractObjectFeatures(self, xmldata, pageReady, htmlAnalysis, scriptAnalysis, urlAnalysis, uri):
        if xmldata is None or pageReady is None:
            print("Insufficient number of parameters")
            return

        if htmlAnalysis:
            self.htmlAnalyzerModule.printAll(xmldata, pageReady, uri)
        if scriptAnalysis:
            self.scriptAnalyzerModule.printAll(xmldata, pageReady, uri)
        if urlAnalysis:
            self.urlAnalyzerModule.printAll(uri)

    def printAnalyzedHTMLFileFeatures(self, filePath, htmlAnalysis = True, scriptAnalysis = True, urlAnalysis = True):
        openedFile = commonConnectionUtils.openFile(filePath)
        if openedFile == []:
            print("Cannot analyze file")
            return

        xmldata = openedFile[0]
        pageReady = openedFile[1]
        self.printAnalyzedAbstractObjectFeatures(xmldata, pageReady, htmlAnalysis, scriptAnalysis, urlAnalysis, filePath)

    def printAnalyzedPageFeatures(self, url, htmlAnalysis = True, scriptAnalysis = True, urlAnalysis = True):
        openedPage = commonConnectionUtils.openPage(url)
        if openedPage == []:
            print("Cannot analyze page")
            return

        xmldata = openedPage[0]
        pageReady = openedPage[1]
        begin = timeit.default_timer()
        self.printAnalyzedAbstractObjectFeatures(xmldata, pageReady, htmlAnalysis, scriptAnalysis, urlAnalysis, url)
        end = timeit.default_timer()
        print("\nprintAnalyzedPageFeatures elapsed time: " + str(end - begin) + " seconds")
    #
    ###################################################################################################################

    # getTotal-functions group
    def getTotalNumberOfAnalyzedAbstractObjectFeatures(self, xmldata, pageReady, htmlAnalysis, scriptAnalysis, urlAnalysis, uri):
        if xmldata is None or pageReady is None:
            print("Insufficient number of parameters")
            return
        resultList = []
        if htmlAnalysis:
            resultList.append(self.htmlAnalyzerModule.getTotalAll(xmldata, pageReady, uri))
        if scriptAnalysis:
            resultList.append(self.scriptAnalyzerModule.getTotalAll(xmldata, pageReady, uri))
        if urlAnalysis:
            resultList.append(self.urlAnalyzerModule.getTotalAll(uri))
        return resultList

    def getTotalNumberOfAnalyzedHTMLFileFeatures(self, filePath, htmlAnalysis = True, scriptAnalysis = True, urlAnalysis = True):
        openedFile = commonConnectionUtils.openFile(filePath)
        if openedFile == []:
            print("Cannot analyze file")
            return

        xmldata = openedFile[0]
        pageReady = openedFile[1]
        self.getTotalNumberOfAnalyzedAbstractObjectFeatures(xmldata, pageReady, htmlAnalysis, scriptAnalysis, urlAnalysis, filePath)

    def getTotalNumberOfAnalyzedPageFeatures(self, url, htmlAnalysis = True, scriptAnalysis = True, urlAnalysis = True):
        openedPage = commonConnectionUtils.openPage(url)
        if openedPage == []:
            print("Cannot analyze page")
            return

        xmldata = openedPage[0]
        pageReady = openedPage[1]
        self.getTotalNumberOfAnalyzedAbstractObjectFeatures(xmldata, pageReady, htmlAnalysis, scriptAnalysis, urlAnalysis, url)
    #
    ###################################################################################################################