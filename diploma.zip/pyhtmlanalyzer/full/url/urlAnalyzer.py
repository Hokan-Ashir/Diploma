import timeit
from pyhtmlanalyzer.full.url.commonURL.commonURLFunctions import commonURLFunctions
from pyhtmlanalyzer.full.url.dns.dnsFunctions import dnsFunctions
from pyhtmlanalyzer.full.url.geoip.geoIPFunctions import geoIPFunctions
from pyhtmlanalyzer.full.url.whoisPackage.whoisFunctions import whoisFunctions

__author__ = 'hokan'


class urlAnalyzer(commonURLFunctions, dnsFunctions, geoIPFunctions, whoisFunctions):
    configDict = None

    # constructor
    def __init__(self, configDict, uri=None):
        commonURLFunctions.__init__(self, configDict, uri)
        dnsFunctions.__init__(self, uri)
        geoIPFunctions.__init__(self, uri)
        whoisFunctions.__init__(self, uri)
        if configDict is None:
            print("\nInvalid parameters")
            return

        self.configDict = configDict
    #
    ###################################################################################################################

    def setURI(self, uri):
        self.uri = uri
        self.retrieveDNShostInfo()
        self.retrieveWHOIShostInfo()
        self.retrieveGeoIPhostInfo()

    # public functions for outer packages
    # print result of all functions via reflection with default values
    # NOTE: no order in function calls
    def printAll(self, uri):
        if uri is None:
            print("Insufficient number of parameters")
            return
        # TODO uncomment
        self.setURI(uri)
        #list_of_domains = ['diagsv3.com', 'google.com', 'abc.com', 'xxxtoolbar.com']
        #printURLVoidScanResults(list_of_domains)
        #printURLVoidScanResults(list_of_domains, True)
        #printURLVoidMaliciousDomains(list_of_domains)
        # TODO remove in production
        #if (True):
        #    return
        print("\n\nurl Analyser ----------------------")
        begin = timeit.default_timer()
        for className in urlAnalyzer.__bases__:
            for funcName, funcValue in className.__dict__.items():
                if str(funcName).startswith("print") and callable(funcValue):
                    try:
                        getattr(self, funcName)()
                    except TypeError:
                        pass
        end = timeit.default_timer()
        print("\nElapsed time: " + str(end - begin) + " seconds")
        print("---------------------------------------")

    #
    ###################################################################################################################

    def getTotalAll(self, uri):
        if uri is None:
            print("Insufficient number of parameters")
            return
        self.uri = uri
        resultDict = {}
        for funcName, funcValue in urlAnalyzer.__dict__.items():
            if str(funcName).startswith("getTotal") and callable(funcValue):
                try:
                    resultDict[funcName] = getattr(self, funcName)()
                except TypeError:
                    pass
        return resultDict
    #
    ###################################################################################################################

    # optimized from 19 to 1.5 seconds

        # TODO list
        # syntactical features
        # the presence of a suspicious domain name (simply must taken from ours db or from urlVoid request)
        #
        # geoip-based
        # netspeed (see no point in it)