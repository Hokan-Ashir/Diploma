import lxml
import lxml.html
import os
from urllib import urlopen
import re

__author__ = 'hokan'

class commonConnectionUtils:
    @staticmethod
    def openFile(filePath):
        try:
            page = open(filePath)
            pageReady = page.read()
        except:
            print("Cannot open file")
            return []
        return [lxml.html.document_fromstring(pageReady), pageReady]

    @staticmethod
    def openPage(url):
        try:
            page = urlopen(url)
            pageReady = page.read()
        except:
            print("Cannot open page")
            return []
        return [lxml.html.document_fromstring(pageReady), pageReady]

    @staticmethod
    def openRelativeScriptObject(uri, filePath):
        # in case 'src=http://path-to-script'
        if str(filePath).startswith('http'):
            openedFile = commonConnectionUtils.openPage(filePath)
        # in case of relative path to script
        else:
            # in case of file analyzing
            if not str(uri).startswith('http'):
                tmpPath = os.path.join(os.path.dirname(uri), filePath)
                openedFile = commonConnectionUtils.openFile(tmpPath)
            # in case of page analyzing
            else:
                # http(s): + // + path-to-TLD + path-to-script
                tmpPath = str(uri).split('/')[0] + '//' + str(uri).split('/')[2] + filePath
                openedFile = commonConnectionUtils.openPage(tmpPath)
        return openedFile